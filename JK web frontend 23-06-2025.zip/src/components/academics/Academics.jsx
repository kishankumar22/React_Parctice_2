import React from 'react'

const Academics = () => {
  return (
    <div>
      
    </div>
  )
}

export default Academics
