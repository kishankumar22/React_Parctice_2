import React from 'react'

const Departments = () => {
  return (
    <div>
      
    </div>
  )
}

export default Departments
